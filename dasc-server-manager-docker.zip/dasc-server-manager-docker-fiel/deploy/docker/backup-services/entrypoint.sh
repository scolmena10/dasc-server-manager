#!/usr/bin/env bash
set -e
cat > /home/dasc/.my.cnf <<'EOF'
[client]
user=dasc_backup
password=dasc_backup_2026
host=192.168.60.20
EOF
cat > /home/dasc/.my_restore.cnf <<'EOF'
[client]
user=dasc_restore
password=dasc_restore_2026
host=192.168.60.20
EOF
chown dasc:dasc /home/dasc/.my.cnf /home/dasc/.my_restore.cnf
chmod 600 /home/dasc/.my.cnf /home/dasc/.my_restore.cnf
/usr/sbin/sshd
exec tail -f /dev/null
