#!/bin/bash
set -e

: "${CACTI_DB_HOST:=cacti-db}"
: "${CACTI_DB_NAME:=cacti}"
: "${CACTI_DB_USER:=cactiuser}"
: "${CACTI_DB_PASS:=proyecto}"
: "${TZ:=Europe/Madrid}"

echo "ServerName localhost" > /etc/apache2/conf-available/servername.conf
a2enconf servername >/dev/null 2>&1 || true

if [ -f /debian.php.template ]; then
  sed \
    -e "s/{{CACTI_DB_HOST}}/${CACTI_DB_HOST}/g" \
    -e "s/{{CACTI_DB_NAME}}/${CACTI_DB_NAME}/g" \
    -e "s/{{CACTI_DB_USER}}/${CACTI_DB_USER}/g" \
    -e "s/{{CACTI_DB_PASS}}/${CACTI_DB_PASS}/g" \
    /debian.php.template > /etc/cacti/debian.php
fi

echo "[cacti] Waiting for DB ${CACTI_DB_HOST}..."
for i in {1..60}; do
  if mariadb-admin ping -h"${CACTI_DB_HOST}" -u"${CACTI_DB_USER}" -p"${CACTI_DB_PASS}" --silent; then
    echo "[cacti] DB is up."
    break
  fi
  sleep 2
done

SQL_FILE=""
for f in \
  /usr/share/cacti/cacti.sql \
  /usr/share/doc/cacti/cacti.sql \
  /usr/share/cacti/cacti.sql.gz \
  /usr/share/doc/cacti/cacti.sql.gz
do
  [ -f "$f" ] && SQL_FILE="$f" && break
done

HAS_TABLES=$(mariadb -h"${CACTI_DB_HOST}" -u"${CACTI_DB_USER}" -p"${CACTI_DB_PASS}" \
  -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${CACTI_DB_NAME}';" -sN 2>/dev/null || echo "0")

if [ "$HAS_TABLES" = "0" ] || [ "$HAS_TABLES" = "" ]; then
  echo "[cacti] Initializing DB schema..."
  if [[ "$SQL_FILE" == *.gz ]]; then
    gzip -dc "$SQL_FILE" | mariadb -h"${CACTI_DB_HOST}" -u"${CACTI_DB_USER}" -p"${CACTI_DB_PASS}" "${CACTI_DB_NAME}"
  elif [ -n "$SQL_FILE" ]; then
    mariadb -h"${CACTI_DB_HOST}" -u"${CACTI_DB_USER}" -p"${CACTI_DB_PASS}" "${CACTI_DB_NAME}" < "$SQL_FILE"
  else
    echo "[cacti] WARNING: No cacti.sql found. You may need to install schema manually."
  fi
fi

echo "[cacti] Configuring admin user..."
mariadb -h"${CACTI_DB_HOST}" \
  -u"${CACTI_DB_USER}" \
  -p"${CACTI_DB_PASS}" \
  "${CACTI_DB_NAME}" \
  -e "UPDATE user_auth SET password=MD5('admin'), enabled='on', must_change_password='' WHERE username='admin';" || true

echo "[cacti] Setting url_path..."
mariadb -h"${CACTI_DB_HOST}" \
  -u"${CACTI_DB_USER}" \
  -p"${CACTI_DB_PASS}" \
  "${CACTI_DB_NAME}" \
  -e "REPLACE INTO settings (name,value) VALUES ('url_path','/cacti/');" || true

echo "[cacti] Fixing PHP sessions..."
mkdir -p /var/lib/php/sessions
chown -R www-data:www-data /var/lib/php/sessions
chmod 1733 /var/lib/php/sessions || true

echo "[cacti] Fixing Cacti writable paths..."
mkdir -p /usr/share/cacti/site/resource/snmp_queries
mkdir -p /usr/share/cacti/site/resource/script_server
mkdir -p /usr/share/cacti/site/resource/script_queries
mkdir -p /usr/share/cacti/site/scripts
mkdir -p /usr/share/cacti/site/include/vendor/csrf

chown -R www-data:www-data /usr/share/cacti/site/resource
chown -R www-data:www-data /usr/share/cacti/site/scripts
chown -R www-data:www-data /usr/share/cacti/site/include

chmod -R 755 /usr/share/cacti/site/resource
chmod -R 755 /usr/share/cacti/site/scripts
chmod -R 755 /usr/share/cacti/site/include

chown -R www-data:www-data /usr/share/cacti/site/resource/snmp_queries/
chown -R www-data:www-data /usr/share/cacti/site/resource/script_server/
chown -R www-data:www-data /usr/share/cacti/site/resource/script_queries/

chmod -R 775 /usr/share/cacti/site/resource/snmp_queries/
chmod -R 775 /usr/share/cacti/site/resource/script_server/
chmod -R 775 /usr/share/cacti/site/resource/script_queries/

echo "[cacti] Ensuring CSRF secret exists..."
CSRF_FILE="/usr/share/cacti/site/include/vendor/csrf/csrf-secret.php"
if [ ! -f "$CSRF_FILE" ]; then
  echo "<?php \$csrf_secret = bin2hex(random_bytes(32));" > "$CSRF_FILE"
  chown www-data:www-data "$CSRF_FILE"
  chmod 640 "$CSRF_FILE"
fi

service cron start >/dev/null 2>&1 || true

exec apache2ctl -D FOREGROUND