#!/bin/bash
set -e

echo "[cacti-db init] Loading timezone tables into mysql database..."
mysql_tzinfo_to_sql /usr/share/zoneinfo | mariadb -uroot -p"${MYSQL_ROOT_PASSWORD}" mysql || true

echo "[cacti-db init] Granting timezone SELECT permission to cacti user..."
mariadb -uroot -p"${MYSQL_ROOT_PASSWORD}" -e "GRANT SELECT ON mysql.time_zone_name TO '${MYSQL_USER}'@'%'; FLUSH PRIVILEGES;" || true

echo "[cacti-db init] Done."
