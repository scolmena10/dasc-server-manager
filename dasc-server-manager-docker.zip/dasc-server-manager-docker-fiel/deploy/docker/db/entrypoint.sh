#!/usr/bin/env bash
set -e
/usr/sbin/sshd
exec docker-entrypoint.sh "$@"
