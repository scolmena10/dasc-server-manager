# DASC Server Manager - Docker fiel al proyecto

Esta carpeta contiene el proyecto actual y una capa Docker pensada para reproducir el entorno de máquinas virtuales sin cambiar la lógica del backend.

## Arranque

```bash
docker compose up -d --build
```

## Accesos

- Panel: http://localhost:8080
- Cacti: http://localhost:8081/cacti/

Credenciales del panel:

```text
admin
1234
```

## Comprobación

```bash
docker compose ps
docker exec mysql-db mariadb -uroot -prootpass -e "SHOW DATABASES;"
docker exec mysql-db mariadb -uroot -prootpass -e "SHOW MASTER STATUS;"
```

## Guía PDF

La guía Docker está en:

```text
docs/guia-docker-dasc-server-manager.pdf
```

También se abre desde el login y desde el panel principal de la versión Docker.
