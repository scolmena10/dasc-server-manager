# Guía Docker - DASC Server Manager

Esta guía explica el despliegue Docker fiel del proyecto DASC Server Manager. El objetivo de esta versión no es sustituir la instalación por máquinas virtuales, sino reproducirla en contenedores manteniendo la misma lógica: panel/API, servidor de base de datos, servidor de backups/servicios, Cacti y documentación accesible desde el panel.

## Diferencia principal frente a las máquinas virtuales

En la instalación por máquinas se trabaja con tres servidores principales:

- 192.168.60.10: panel/API DASC.
- 192.168.60.20: MariaDB y logs.
- 192.168.60.30: backups y servicios.

En Docker se mantiene esa misma idea usando una red Docker con IPs fijas. El panel sigue ejecutando el mismo backend y llamando por SSH a los scripts del servidor de backups. No se ha cambiado el modelo de funcionamiento a una gestión artificial de contenedores.

## Servicios del stack

| Servicio | IP interna | Función |
|---|---:|---|
| dasc-web | 192.168.60.10 | Panel FastAPI y frontend |
| mysql-db | 192.168.60.20 | MariaDB, employees y dasc_logs |
| backup-services | 192.168.60.30 | Scripts de backups, restauración y servicios |
| cacti | interna | Monitorización web en el puerto 8081 |
| cacti-db | interna | Base de datos interna de Cacti |

## Requisitos

- Docker Desktop en Windows o Docker Engine en Linux.
- WSL2 y virtualización habilitada si se usa Windows.
- Conexión a Internet para descargar imágenes la primera vez.

## Puesta en marcha

```bash
cd dasc-server-manager-docker-fiel
docker compose up -d --build
```

Después se comprueba el estado:

```bash
docker compose ps
```

El panel estará disponible en:

```text
http://localhost:8080
```

Cacti estará disponible en:

```text
http://localhost:8081/cacti/
```

## Credenciales del panel

Las credenciales iniciales se mantienen como en el proyecto actual:

```text
Usuario: admin
Contraseña: 1234
```

## Comprobaciones básicas

Comprobar que MariaDB responde:

```bash
docker exec mysql-db mariadb -uroot -prootpass -e "SHOW DATABASES;"
```

Comprobar que los binlogs están activos:

```bash
docker exec mysql-db mariadb -uroot -prootpass -e "SHOW MASTER STATUS;"
```

Comprobar conexión SSH del panel al servidor de backups:

```bash
docker exec dasc-web ssh -i /opt/dasc/api/.ssh/id_rsa_dasc -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/opt/dasc/api/.ssh/known_hosts_dasc dasc@192.168.60.30 hostname
```

Comprobar conexión SSH del panel al servidor de base de datos:

```bash
docker exec dasc-web ssh -i /opt/dasc/api/.ssh/id_rsa_dasc -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/opt/dasc/api/.ssh/known_hosts_dasc dasc@192.168.60.20 hostname
```

## Prueba de backups

Backup completo:

```bash
docker exec backup-services sudo -u dasc /usr/local/bin/backups_api.sh full employees /home/dasc/backups prueba-full-YYYYMMDD-HHMM.sql gzip 30 manual prueba
```

Cambio en la base de datos:

```bash
docker exec mysql-db mariadb -uroot -prootpass employees -e "INSERT INTO empleados_demo(nombre) VALUES('PruebaDocker');"
```

Backup incremental:

```bash
docker exec backup-services sudo -u dasc /usr/local/bin/backups_api.sh incremental employees /home/dasc/backups prueba-inc-YYYYMMDD-HHMM.sql gzip 30 latest prueba
```

Backup diferencial:

```bash
docker exec backup-services sudo -u dasc /usr/local/bin/backups_api.sh differential employees /home/dasc/backups prueba-diff-YYYYMMDD-HHMM.sql gzip 30 last_full prueba
```

Historial:

```bash
docker exec backup-services cat /home/dasc/backups/.dasc/history.tsv
```

## Uso desde el panel

Desde el panel se prueban las mismas secciones que en la versión de máquinas virtuales:

- Copias: creación, historial, descarga y restauración si está disponible en el proyecto base.
- Servicios: listado y acciones mediante el script servicios_api.sh.
- Logs: eventos registrados en la base dasc_logs.
- Terminal: acceso a Main, Backup y Database con los permisos configurados.
- Alertas: configuración de Telegram según el estado del proyecto.

## Parar y reiniciar

Parar sin borrar datos:

```bash
docker compose down
```

Volver a levantar:

```bash
docker compose up -d
```

Borrar todo y empezar desde cero:

```bash
docker compose down -v
docker compose up -d --build
```

## Qué se ha mantenido fiel al proyecto

- Se usa el main.py actual del proyecto.
- Se usan las plantillas HTML actuales.
- Se usan los CSS actuales.
- Se usan los scripts actuales de backups, restauración y servicios.
- Se mantiene el modelo SSH entre el panel y los servidores.
- Se mantiene el esquema de IPs del laboratorio.

## Única diferencia añadida en Docker

La versión Docker incluye un enlace a esta guía en el login y en el panel principal. Este enlace es exclusivo de la demo Docker y no es necesario en la instalación por máquinas virtuales.
